<header>
	<div class="sidebar">
		<div class="bar">
			<i class="fa-solid fa-bars"></i>
		</div>
		<h1  class="title none">Financial Management</h1>
	</div>
	<div class="icons">
		 <div id="MyClockDisplay" class="clock" onload="showTime()"></div>
		<div class="out">
			 <img class="avatar" src="../uploads/<?php echo $fetch_username["profile"] ?>">
			<i class="fa-solid fa-caret-down down">
				<div class="drp_menu">
					<div class="logout">
					<a href="logout.php">
			        <span  class="icon"><i class="fa-solid fa-right-from-bracket"></i></span><span class="texts">Logout</span>
			    	</a>
					</div>
				</div>
			</i>
		</div>
		<!-- <i class="fa-solid fa-bell"></i> -->
	</div>
</header>


