let activePage = window.location.pathname;
let navLinks = document.querySelectorAll('a');

navLinks.forEach(item => {
    if(item.href.includes(`${activePage}`)) {
        item.classList.add('active');
    }
});

let navBtn = document.querySelector('.bar');
let sideBar = document.querySelector('nav');
let ul = document.querySelector('ul');
let changeIcon = document.querySelector('.fa-bars');
let main = document.querySelector('main');

navBtn.addEventListener('click', () => {
    main.classList.toggle('slide');
});

let closed = document.querySelector('.closed');
    closed.addEventListener('click', ()=> {
    main.classList.remove('slide');
});


let down = document.querySelector('.down');
let drp_menu = document.querySelector('.drp_menu');

down.addEventListener('click', () => {
	drp_menu.classList.toggle('out');
});

document.onclick = function(e) {
	if(down !== e.target && drp_menu !== e.target) {
		drp_menu.classList.remove('out');
	}
}


